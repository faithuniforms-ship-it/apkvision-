APKVision GitHub Pages starter

Files:
- index.html: site homepage
- google-llc/android-acsessibility-suite/index.html: requested app page route

Before publishing:
1. Upload these files to the root of your public GitHub repository.
2. Add the real APK file named exactly:
   com.google.android.marvin.talkback_v48892_arm64v8a.apk
   Put it in the repository root so the Download button can find it.
3. In GitHub, open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.

The Download button shows “Download starting.” and points to the APK filename above.
The APK itself is not included in this ZIP.
